export class Student {
  id: number;
  name: string;
  dateOfBirth: string;

  constructor(id: number, name: string, dateOfBirth: string) {
    this.id = id;
    this.name = name;
    this.dateOfBirth = dateOfBirth;
  }
}
