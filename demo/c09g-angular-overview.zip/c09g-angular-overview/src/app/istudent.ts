export interface IStudent {
}
